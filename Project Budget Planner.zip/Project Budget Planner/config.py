"""
Configuration file for the application
"""

# Database Configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'root',  # Change this to your MySQL password
    'database': 'expense_db',
    'port': 3306
}

# Application Settings
APP_CONFIG = {
    'title': 'Expense Tracker',
    'icon': '',  # Removed icon
    'layout': 'wide',
    'currency_symbol': 'Rs.',
    'date_format': '%Y-%m-%d',
    'month_format': '%Y-%m'
}

# Color scheme
COLORS = {
    'income': 'green',
    'expense': 'red',
    'balance_positive': 'green',
    'balance_negative': 'red',
    'chart_colors': ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F']
}