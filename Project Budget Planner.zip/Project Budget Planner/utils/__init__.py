"""
Utility modules for Expense Tracker
"""