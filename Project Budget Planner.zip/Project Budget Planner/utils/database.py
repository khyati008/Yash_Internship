import pymysql
from pymysql.cursors import DictCursor
from contextlib import contextmanager
from config import DB_CONFIG
import streamlit as st

@contextmanager
def get_db_connection():
    """Context manager for database connections"""
    connection = None
    try:
        connection = pymysql.connect(
            host=DB_CONFIG['host'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database'],
            port=DB_CONFIG['port'],
            cursorclass=DictCursor
        )
        yield connection
        connection.commit()
    except Exception as e:
        if connection:
            connection.rollback()
        raise e
    finally:
        if connection:
            connection.close()

def init_database():
    """Initialize database and tables"""
    try:
        connection = pymysql.connect(
            host=DB_CONFIG['host'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            port=DB_CONFIG['port']
        )
        
        with connection.cursor() as cursor:
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DB_CONFIG['database']}")
        connection.commit()
        connection.close()
        
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                # Create categories table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS categories (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(50) NOT NULL,
                        type ENUM('Income', 'Expense') NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Create expenses table WITHOUT description field
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS expenses (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        category_id INT,
                        amount DECIMAL(10, 2) NOT NULL,
                        date DATE NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (category_id) REFERENCES categories(id)
                    )
                """)
                
                # Check if categories exist
                cursor.execute("SELECT COUNT(*) as count FROM categories")
                if cursor.fetchone()['count'] == 0:
                    categories = [
                        ('Salary', 'Income'),
                        ('Business', 'Income'),
                        ('Freelance', 'Income'),
                        ('Investment', 'Income'),
                        ('Food', 'Expense'),
                        ('Transport', 'Expense'),
                        ('Shopping', 'Expense'),
                        ('Bills', 'Expense'),
                        ('Entertainment', 'Expense'),
                        ('Health', 'Expense'),
                        ('Education', 'Expense'),
                        ('Rent', 'Expense'),
                        ('Other', 'Expense')
                    ]
                    cursor.executemany(
                        "INSERT INTO categories (name, type) VALUES (%s, %s)",
                        categories
                    )
        
        return True
    except Exception as e:
        st.error(f"Database initialization error: {str(e)}")
        return False

# ==================== CATEGORY FUNCTIONS ====================

def get_all_categories():
    """Get all categories"""
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM categories ORDER BY type, name")
                return cursor.fetchall()
    except Exception as e:
        st.error(f"Error fetching categories: {str(e)}")
        return []

def get_categories_by_type(category_type):
    """Get categories by type (Income/Expense)"""
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(
                    "SELECT * FROM categories WHERE type = %s ORDER BY name",
                    (category_type,)
                )
                return cursor.fetchall()
    except Exception as e:
        st.error(f"Error fetching categories: {str(e)}")
        return []

def add_category(name, category_type):
    """Add a new category"""
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(
                    "INSERT INTO categories (name, type) VALUES (%s, %s)",
                    (name, category_type)
                )
                return cursor.lastrowid
    except Exception as e:
        st.error(f"Error adding category: {str(e)}")
        return None

# ==================== EXPENSE FUNCTIONS ====================

def get_all_expenses(start_date=None, end_date=None, category_id=None):
    """Get all expenses with optional filters"""
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                query = """
                    SELECT e.*, c.name as category_name, c.type as category_type
                    FROM expenses e
                    JOIN categories c ON e.category_id = c.id
                    WHERE 1=1
                """
                params = []
                
                if start_date:
                    query += " AND e.date >= %s"
                    params.append(start_date)
                
                if end_date:
                    query += " AND e.date <= %s"
                    params.append(end_date)
                
                if category_id:
                    query += " AND e.category_id = %s"
                    params.append(category_id)
                
                query += " ORDER BY e.date DESC, e.id DESC"
                
                cursor.execute(query, params)
                return cursor.fetchall()
    except Exception as e:
        st.error(f"Error fetching expenses: {str(e)}")
        return []

def add_expense(category_id, amount, date):
    """Add a new expense - WITHOUT description"""
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO expenses (category_id, amount, date)
                    VALUES (%s, %s, %s)
                    """,
                    (category_id, amount, date)
                )
                return cursor.lastrowid
    except Exception as e:
        st.error(f"Error adding expense: {str(e)}")
        return None

def update_expense(expense_id, category_id, amount, date):
    """Update an expense - WITHOUT description"""
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(
                    """
                    UPDATE expenses 
                    SET category_id = %s, amount = %s, date = %s
                    WHERE id = %s
                    """,
                    (category_id, amount, date, expense_id)
                )
                return cursor.rowcount > 0
    except Exception as e:
        st.error(f"Error updating expense: {str(e)}")
        return False

def delete_expense(expense_id):
    """Delete an expense"""
    try:
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("DELETE FROM expenses WHERE id = %s", (expense_id,))
                return cursor.rowcount > 0
    except Exception as e:
        st.error(f"Error deleting expense: {str(e)}")
        return False

# ==================== ANALYTICS FUNCTIONS ====================

def get_summary(month=None):
    """Get financial summary"""
    try:
        import pandas as pd
        import numpy as np
        
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                query = """
                    SELECT e.amount, c.type
                    FROM expenses e
                    JOIN categories c ON e.category_id = c.id
                """
                params = []
                
                if month:
                    query += " WHERE DATE_FORMAT(e.date, '%%Y-%%m') = %s"
                    params.append(month)
                
                cursor.execute(query, params)
                data = cursor.fetchall()
        
        if not data:
            return {
                'total_income': 0.0,
                'total_expense': 0.0,
                'balance': 0.0,
                'count': 0,
                'avg_income': 0.0,
                'avg_expense': 0.0
            }
        
        df = pd.DataFrame(data)
        income_df = df[df['type'] == 'Income']
        expense_df = df[df['type'] == 'Expense']
        
        total_income = float(np.sum(income_df['amount'].values)) if len(income_df) > 0 else 0.0
        total_expense = float(np.sum(expense_df['amount'].values)) if len(expense_df) > 0 else 0.0
        avg_income = float(np.mean(income_df['amount'].values)) if len(income_df) > 0 else 0.0
        avg_expense = float(np.mean(expense_df['amount'].values)) if len(expense_df) > 0 else 0.0
        
        return {
            'total_income': round(total_income, 2),
            'total_expense': round(total_expense, 2),
            'balance': round(total_income - total_expense, 2),
            'count': len(data),
            'avg_income': round(avg_income, 2),
            'avg_expense': round(avg_expense, 2)
        }
    except Exception as e:
        st.error(f"Error getting summary: {str(e)}")
        return {
            'total_income': 0.0,
            'total_expense': 0.0,
            'balance': 0.0,
            'count': 0,
            'avg_income': 0.0,
            'avg_expense': 0.0
        }

def get_category_summary(month=None):
    """Get category-wise summary"""
    try:
        import numpy as np
        
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                query = """
                    SELECT c.name, c.type, SUM(e.amount) as total, COUNT(e.id) as count
                    FROM expenses e
                    JOIN categories c ON e.category_id = c.id
                """
                params = []
                
                if month:
                    query += " WHERE DATE_FORMAT(e.date, '%%Y-%%m') = %s"
                    params.append(month)
                
                query += " GROUP BY c.id, c.name, c.type ORDER BY total DESC"
                
                cursor.execute(query, params)
                results = cursor.fetchall()
        
        if not results:
            return []
        
        totals = np.array([float(r['total']) for r in results])
        grand_total = np.sum(totals)
        
        for i, result in enumerate(results):
            result['total'] = float(result['total'])
            result['percentage'] = round(float((totals[i] / grand_total) * 100), 2) if grand_total > 0 else 0.0
        
        return results
    except Exception as e:
        st.error(f"Error getting category summary: {str(e)}")
        return []

def get_monthly_trend(months=6):
    """Get monthly trend"""
    try:
        import pandas as pd
        
        with get_db_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute("""
                    SELECT 
                        DATE_FORMAT(e.date, '%%Y-%%m') as month,
                        c.type,
                        SUM(e.amount) as total
                    FROM expenses e
                    JOIN categories c ON e.category_id = c.id
                    WHERE e.date >= DATE_SUB(CURDATE(), INTERVAL %s MONTH)
                    GROUP BY month, c.type
                    ORDER BY month ASC
                """, (months,))
                results = cursor.fetchall()
        
        if not results:
            return []
        
        df = pd.DataFrame(results)
        pivot = df.pivot_table(
            index='month',
            columns='type',
            values='total',
            fill_value=0
        ).reset_index()
        
        if 'Income' in pivot.columns and 'Expense' in pivot.columns:
            pivot['Balance'] = pivot['Income'] - pivot['Expense']
        elif 'Income' in pivot.columns:
            pivot['Balance'] = pivot['Income']
        elif 'Expense' in pivot.columns:
            pivot['Balance'] = -pivot['Expense']
        else:
            pivot['Balance'] = 0
        
        return pivot.to_dict('records')
    except Exception as e:
        st.error(f"Error getting monthly trend: {str(e)}")
        return []