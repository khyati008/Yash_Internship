from config import APP_CONFIG

def format_currency(amount):
    """Format amount as currency"""
    currency_symbol = APP_CONFIG['currency_symbol']
    return f"{currency_symbol} {amount:,.2f}"