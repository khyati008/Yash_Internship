import streamlit as st
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from utils.database import init_database, get_summary, get_category_summary, get_monthly_trend
from utils.helpers import format_currency
from config import APP_CONFIG

# Page config
st.set_page_config(
    page_title=APP_CONFIG['title'],
    page_icon=None,
    layout=APP_CONFIG['layout']
)

# Initialize database
if 'db_initialized' not in st.session_state:
    with st.spinner("Initializing database..."):
        if init_database():
            st.session_state.db_initialized = True
        else:
            st.error("Failed to initialize database. Please check your configuration.")
            st.stop()

# Custom CSS
st.markdown("""
    <style>
    .main-header {
        font-size: 3rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    </style>
""", unsafe_allow_html=True)

# Header
st.markdown(f'<h1 class="main-header">{APP_CONFIG["title"]}</h1>', unsafe_allow_html=True)
st.markdown("---")

# Welcome message
st.write("### Welcome to Your Personal Finance Manager")
st.info("Track your income and expenses easily. Navigate using the sidebar!")

# Month selector for dashboard

st.markdown("---")
st.subheader("Financial Dashboard")

col1, col2 = st.columns([3, 1])
with col1:
    current_month = datetime.now().strftime(APP_CONFIG['month_format'])
    selected_month = st.selectbox("Select Month for Analysis", [current_month], index=0)

with col2:
    st.write("")
    st.write("")
    if st.button("Refresh Data", use_container_width=True):
        st.rerun()

# Get summary data
summary = get_summary(selected_month)
category_data = get_category_summary(selected_month)
trend_data = get_monthly_trend(6)

if summary:
    # Main metrics
    st.write("### Monthly Summary")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Income", format_currency(summary['total_income']))
    
    with col2:
        st.metric("Total Expense", format_currency(summary['total_expense']))
    
    with col3:
        balance = summary['balance']
        delta_type = "normal" if balance >= 0 else "inverse"
        st.metric("Balance", format_currency(balance))
    
    with col4:
        st.metric("Transactions", summary['count'])
    
    # Additional stats
    st.markdown("---")
    st.write("### Quick Stats")
    col1, col2 = st.columns(2)
    
    with col1:
        if summary and summary['avg_income'] > 0:
            st.info(f"Average Income: {format_currency(summary['avg_income'])}")
        else:
            st.info(f"Average Income: {format_currency(0)}")
    
    with col2:
        if summary and summary['avg_expense'] > 0:
            st.warning(f"Average Expense: {format_currency(summary['avg_expense'])}")
        else:
            st.warning(f"Average Expense: {format_currency(0)}")
    
    # Charts section
    if category_data and len(category_data) > 0:
        st.markdown("---")
        st.write("### Category Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("Expenses by Category")
            expense_data = [d for d in category_data if d['type'] == 'Expense']
            
            if expense_data:
                fig, ax = plt.subplots(figsize=(8, 8))
                labels = [d['name'] for d in expense_data]
                sizes = [d['total'] for d in expense_data]
                colors = plt.cm.Set3(np.linspace(0, 1, len(labels)))
                
                ax.pie(sizes, labels=labels, autopct='%1.1f%%', colors=colors, startangle=90)
                ax.axis('equal')
                
                st.pyplot(fig)
                plt.close()
            else:
                st.info("No expense data for this month")
        
        with col2:
            st.subheader("Category Breakdown")
            
            if category_data:
                fig, ax = plt.subplots(figsize=(8, 8))
                categories = [d['name'] for d in category_data]
                amounts = [d['total'] for d in category_data]
                colors_list = ['green' if d['type'] == 'Income' else 'red' for d in category_data]
                
                ax.barh(categories, amounts, color=colors_list)
                ax.set_xlabel('Amount')
                ax.set_title('Income vs Expenses')
                ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'Rs. {x:,.0f}'))
                
                st.pyplot(fig)
                plt.close()
    
    # Monthly trend
    st.markdown("---")
    st.write("### Monthly Trend (Last 6 Months)")
    
    if trend_data and len(trend_data) > 0:
        df_trend = pd.DataFrame(trend_data)
        
        fig, ax = plt.subplots(figsize=(12, 6))
        months = df_trend['month'].tolist()
        x = np.arange(len(months))
        width = 0.35
        
        income = df_trend['Income'].tolist() if 'Income' in df_trend.columns else [0] * len(months)
        expense = df_trend['Expense'].tolist() if 'Expense' in df_trend.columns else [0] * len(months)
        
        ax.bar(x - width/2, income, width, label='Income', color='green', alpha=0.7)
        ax.bar(x + width/2, expense, width, label='Expense', color='red', alpha=0.7)
        
        ax.set_xlabel('Month')
        ax.set_ylabel('Amount')
        ax.set_title('Income vs Expense Trend')
        ax.set_xticks(x)
        ax.set_xticklabels(months, rotation=45)
        ax.legend()
        ax.grid(axis='y', alpha=0.3)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, p: f'Rs. {x:,.0f}'))
        
        plt.tight_layout()
        st.pyplot(fig)
        plt.close()
    else:
        st.info("Add more transactions to see monthly trends (requires data from multiple months)")
    
    # Detailed table
    st.markdown("---")
    st.write("### Detailed Category Breakdown")
    
    if category_data:
        df_category = pd.DataFrame(category_data)
        
        # Format the data for display
        display_data = []
        for _, row in df_category.iterrows():
            display_data.append({
                'Category': row['name'],
                'Type': row['type'],
                'Total Amount': format_currency(row['total']),
                'Transaction Count': row['count'],
                'Percentage': f"{row['percentage']}%"
            })
        
        df_display = pd.DataFrame(display_data)
        st.dataframe(df_display, use_container_width=True, hide_index=True)
        
        # Download option
        csv = df_category.to_csv(index=False)
        st.download_button(
            label="Download Category Report as CSV",
            data=csv,
            file_name=f"category_report_{selected_month}.csv",
            mime="text/csv"
        )
    else:
        st.info("No category data available for this month")

else:
    st.warning("No financial data available. Start by adding your first transaction!")

# Getting Started section
st.markdown("---")
st.write("### Getting Started")
st.markdown("""
1. **Add Transaction**: Use the 'Add Expense' page to record income and expenses
2. **View History**: Check 'View Expenses' page to see all your transactions with filters
3. **Analyze**: The dashboard above shows your financial overview with charts and trends
4. **Export Data**: Download your data as CSV for backup or further analysis
""")

