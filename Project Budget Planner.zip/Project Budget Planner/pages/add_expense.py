import streamlit as st
from datetime import date
import pandas as pd
from utils.database import get_all_categories, add_expense, get_all_expenses, delete_expense
from utils.helpers import format_currency

st.set_page_config(page_title="Add Expense", page_icon=None, layout="wide")

st.title("Add New Transaction")
st.markdown("---")

# Get categories
categories = get_all_categories()

if not categories:
    st.error("No categories found. Please check database connection.")
    st.stop()

# Create two columns
col1, col2 = st.columns(2)

with col2:
    st.subheader("Add Expense")
    
    expense_categories = [c for c in categories if c['type'] == 'Expense']
    expense_names = [c['name'] for c in expense_categories]
    
    with st.form("expense_form", clear_on_submit=True):
        selected_category = st.selectbox("Category", expense_names, key="exp_cat")
        amount = st.number_input("Amount", min_value=0.00, step=0.00, format="%.2f", key="exp_amt")
        transaction_date = st.date_input("Date", value=date.today(), key="exp_date")
        
        submitted = st.form_submit_button("Add Expense", use_container_width=True)
        
        if submitted:
            category_id = next(c['id'] for c in expense_categories if c['name'] == selected_category)
            
            # Call with 3 parameters: category_id, amount, date
            result = add_expense(category_id, amount, transaction_date)
            
            if result:
                st.success(f"Expense of {format_currency(amount)} added successfully!")
                
              

with col1:
    st.subheader("Add Income")
    
    income_categories = [c for c in categories if c['type'] == 'Income']
    income_names = [c['name'] for c in income_categories]
    
    with st.form("income_form", clear_on_submit=True):
        selected_income = st.selectbox("Category", income_names, key="inc_cat")
        income_amount = st.number_input("Amount", min_value=0.00, step=0.00, format="%.2f", key="inc_amt")
        income_date = st.date_input("Date", value=date.today(), key="inc_date")
        
        submitted_income = st.form_submit_button("Add Income", use_container_width=True)
        
        if submitted_income:
            category_id = next(c['id'] for c in income_categories if c['name'] == selected_income)
            
            # Call with 3 parameters: category_id, amount, date
            result = add_expense(category_id, income_amount, income_date)
            
            if result:
                st.success(f"Income of {format_currency(income_amount)} added successfully!")
        
# Recent transactions
st.markdown("---")
st.subheader("Recent Transactions")

col1, col2, col3 = st.columns([1, 1, 4])
with col1:
    if st.button("Refresh", use_container_width=True):
        st.rerun()

with col2:
    filter_type = st.selectbox("Filter", ["All", "Income Only", "Expense Only"])

recent_expenses = get_all_expenses()

if recent_expenses:
    if filter_type == "Income Only":
        recent_expenses = [t for t in recent_expenses if t['category_type'] == 'Income']
    elif filter_type == "Expense Only":
        recent_expenses = [t for t in recent_expenses if t['category_type'] == 'Expense']
    
    recent_expenses = recent_expenses[:20]
    
    if len(recent_expenses) > 0:
        df_data = []
        for expense in recent_expenses:
            df_data.append({
                'Date': expense['date'],
                'Type': expense['category_type'],
                'Category': expense['category_name'],
                'Amount': expense['amount'],
            })
        
        df = pd.DataFrame(df_data)
        
        col1, col2, col3 = st.columns(3)
        
        total_income = df[df['Type'] == 'Income']['Amount'].sum() if 'Income' in df['Type'].values else 0
        total_expense = df[df['Type'] == 'Expense']['Amount'].sum() if 'Expense' in df['Type'].values else 0
        
        with col1:
            st.metric("Total Income", format_currency(total_income))
        with col2:
            st.metric("Total Expense", format_currency(total_expense))
        with col3:
            st.metric("Net", format_currency(total_income - total_expense))
        
        st.markdown("---")
        
        st.dataframe(
            df,
            column_config={
                'Amount': st.column_config.NumberColumn('Amount', format="Rs. %.2f")
            },
            hide_index=True,
            use_container_width=True,
            height=400
        )

        st.markdown("---")
       
    else:
        st.info(f"No {filter_type.lower()} transactions found.")
else:
    st.info("No transactions yet. Add your first transaction above!")
