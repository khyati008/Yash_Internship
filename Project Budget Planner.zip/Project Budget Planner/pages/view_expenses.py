import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
from utils.database import get_all_expenses, delete_expense
from utils.helpers import format_currency

st.set_page_config(page_title="View Expenses", page_icon=None, layout="wide")

st.title("View All Transactions")
st.markdown("---")

# Filters
col1, col2, col3 = st.columns(3)

with col1:
    filter_type = st.selectbox("Filter by Type", ["All", "Income", "Expense"])

with col2:
    date_range = st.selectbox(
        "Date Range",
        ["All Time", "This Month", "Last Month", "Last 3 Months", "Custom"]
    )

with col3:
    if date_range == "Custom":
        custom_date = st.date_input("Select Date")
    else:
        custom_date = None

# Calculate date filters
start_date = None
end_date = None

if date_range == "This Month":
    start_date = datetime.now().replace(day=1).date()
    end_date = datetime.now().date()
elif date_range == "Last Month":
    first_day_this_month = datetime.now().replace(day=1)
    last_day_last_month = first_day_this_month - timedelta(days=1)
    start_date = last_day_last_month.replace(day=1)
    end_date = last_day_last_month
elif date_range == "Last 3 Months":
    end_date = datetime.now().date()
    start_date = (datetime.now() - timedelta(days=90)).date()
elif date_range == "Custom" and custom_date:
    start_date = custom_date
    end_date = custom_date

# Get expenses
expenses = get_all_expenses(start_date, end_date)

if expenses:
    if filter_type != "All":
        expenses = [e for e in expenses if e['category_type'] == filter_type]
    
    if len(expenses) > 0:
        df = pd.DataFrame(expenses)
        
        total_income = df[df['category_type'] == 'Income']['amount'].sum()
        total_expense = df[df['category_type'] == 'Expense']['amount'].sum()
        balance = total_income - total_expense
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Income", format_currency(total_income))
        with col2:
            st.metric("Total Expense", format_currency(total_expense))
        with col3:
            st.metric("Balance", format_currency(balance))
        
        st.markdown("---")
        st.subheader(f"Showing {len(expenses)} transactions")
        
        for expense in expenses:
            with st.container():
                col1, col2, col3, col4 = st.columns([2, 2, 2, 1])
                
                with col1:
                    st.write(f"**{expense['category_name']}**")
                
                with col2:
                    color = "red" if expense['category_type'] == 'Expense' else "green"
                    st.markdown(f":{color}[**{format_currency(expense['amount'])}**]")
                
                with col3:
                    st.write(f"{expense['date']}")
                
                with col4:
                    if st.button("Delete", key=f"del_{expense['id']}"):
                        if delete_expense(expense['id']):
                            st.success("Deleted!")
                            st.rerun()
                
                st.divider()
        
        st.markdown("---")
        csv = df.to_csv(index=False)
        st.download_button(
            label="Download as CSV",
            data=csv,
            file_name=f"expenses_{datetime.now().strftime('%Y%m%d')}.csv",
            mime="text/csv"
        )
    else:
        st.info("No transactions found for the selected filters.")
else:
    st.info("No transactions yet. Add your first transaction!")