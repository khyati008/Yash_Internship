CREATE DATABASE IF NOT EXISTS expense_db;
USE expense_db;

CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    type ENUM('Income', 'Expense') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS expenses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    amount DECIMAL(10, 2) NOT NULL,
    description TEXT,
    date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

INSERT INTO categories (name, type) VALUES
('Salary', 'Income'),
('Business', 'Income'),
('Freelance', 'Income'),
('Investment', 'Income'),
('Food', 'Expense'),
('Transport', 'Expense'),
('Shopping', 'Expense'),
('Bills', 'Expense'),
('Entertainment', 'Expense'),
('Health', 'Expense'),
('Education', 'Expense'),
('Rent', 'Expense'),
('Other', 'Expense');