import pymysql
from pymysql import Error
import sys

def get_db():   
    try:
        print(">>> Attempting PyMySQL connection...", file=sys.stderr)
        connection = pymysql.connect(
            host='localhost',
            database='test_system',
            user='root',
            password='root',
            port=3306,
            autocommit=False,
        )
        print(f">>> Connection successful: {connection}", file=sys.stderr)
        return connection
            
    except Exception as e:
        print(f">>> Database connection error: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc(file=sys.stderr)
        return None
    
def close_db(connection, cursor=None):
    try:
        print(">>> close_db called", file=sys.stderr)
        if cursor:
            cursor.close()
            print(">>> Cursor closed", file=sys.stderr)
        if connection and connection.open:
            connection.close()
            print(">>> Connection closed", file=sys.stderr)
    except Exception as e:
        print(f">>> Error closing connection: {e}", file=sys.stderr)