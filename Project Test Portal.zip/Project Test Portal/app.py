import streamlit as st
from utils.session import init_session, logout_user, require_auth, require_admin, require_student
from main.register import register
from main.login import login
from admin.dashboard import admin_dashboard
from student.dashboard import student_dashboard
from admin.test_manager import create_test
from admin.ques_manager import add_questions
from admin.manage_tests import manage_tests    
from student.test_portal import available_tests, attempt_test
from student.reports import student_reports
from admin.reports import admin_reports

# Page configuration
st.set_page_config(
    page_title="Test Portal",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Load CSS
def load_css():
    try:
        with open("style.css") as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
    except FileNotFoundError:
        st.warning("CSS file not found.")

load_css()

# Initialize session
init_session()

# Sidebar for logged-in user
if st.session_state.user:
    with st.sidebar:
        st.markdown(f"### Welcome, {st.session_state.user['name']}!")
        st.markdown(f"**Role:** {st.session_state.user['role'].title()}")
        st.markdown("---")
        
        if st.button(" Home", use_container_width=True):
            st.session_state.page = "home"
            st.rerun()
        
        if st.button("Logout", use_container_width=True):
            logout_user()

# Main page routing
page = st.session_state.page

# Public pages (no authentication required)
if page == "home":
    st.title("Online Test Portal")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown("""
        <div class="card">
            <h2 style="text-align: center; color: ##92806c;">Welcome to Test Portal</h2>
            <p style="text-align: center; color: ##92806c; font-size: 16px;">
                Take tests, track progress, and improve your skills
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        if not st.session_state.user:
            col_a, col_b = st.columns(2)
            with col_a:
                if st.button("Login", use_container_width=True):
                    st.session_state.page = "login"
                    st.rerun()
            with col_b:
                if st.button("Register", use_container_width=True):
                    st.session_state.page = "register"
                    st.rerun()
        else:
            if st.session_state.user['role'] == 'admin':
                if st.button("Admin Dashboard", use_container_width=True):
                    st.session_state.page = "admin"
                    st.rerun()
            else:
                if st.button("Student Dashboard", use_container_width=True):
                    st.session_state.page = "student"
                    st.rerun()

elif page == "login":
    login()

elif page == "register":
    register()

# Admin pages (require admin authentication)
elif page == "admin":
    require_admin()
    admin_dashboard()

elif page == "create_test":
    require_admin()
    create_test()

elif page == "add_questions":
    require_admin()
    add_questions()
elif page == "manage_tests":               # ← NEW
    require_admin()
    manage_tests()

elif page == "admin_reports":
    require_admin()
    admin_reports()

# Student pages (require student authentication)
elif page == "student":
    require_student()
    student_dashboard()

elif page == "available_tests":
    require_student()
    available_tests()

elif page == "attempt_test":
    require_student()
    attempt_test()

elif page == "student_reports":
    require_student()
    student_reports()

# Error page
else:
    st.error("Page not found!")
    if st.button("Go Home"):
        st.session_state.page = "home"
        st.rerun()