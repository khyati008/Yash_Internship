import streamlit as st
import bcrypt
import pymysql
from database.db_connection import get_db, close_db
import sys

def register():
    print("\n >>>REGISTER FUNCTION CALLED", file=sys.stderr)
    
    st.title("User Registration")

    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        name = st.text_input("Full Name", placeholder="Enter your full name")
        email = st.text_input("Email", placeholder="your.email@example.com")
        password = st.text_input("Password", type="password", placeholder="Minimum 6 characters")
        role = st.selectbox("Register As", ["student", "admin"])

        col_a, col_b = st.columns(2)
        
        with col_a:
            if st.button("Register", use_container_width=True):
                print("\n>>> REGISTER BUTTON CLICKED", file=sys.stderr)
                
                # Validation
                if not name or not email or not password:
                    print(">>> Validation failed: Empty fields", file=sys.stderr)
                    st.warning("Please fill all the fields")
                    return
                    
                if len(password) < 6:
                    print(">>> Validation failed: Password too short", file=sys.stderr)
                    st.warning("Password must be at least 6 characters")
                    return
                    
                if "@" not in email:
                    print(">>> Validation failed: Invalid email", file=sys.stderr)
                    st.error("Invalid email address")
                    return
                
                print(f">>> Validation passed for email: {email}", file=sys.stderr)
                
                # Hash password
                try:
                    print(">>> Hashing password...", file=sys.stderr)
                    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
                    print(">>> Password hashed successfully", file=sys.stderr)
                except Exception as e:
                    print(f">>> ERROR hashing password: {e}", file=sys.stderr)
                    st.error(f"Error: {e}")
                    return
                
                # Database operation
                db = None
                cur = None
                
                try:
                    print(">>> Getting database connection...", file=sys.stderr)
                    db = get_db()
                    print(f">>> Database connection object: {db}", file=sys.stderr)
                    
                    if db:
                        print(">>> Creating cursor...", file=sys.stderr)
                        cur = db.cursor()
                        print(">>> Cursor created", file=sys.stderr)
                        
                        print(">>> Executing INSERT query...", file=sys.stderr)
                        cur.execute(
                            "INSERT INTO users(name, email, password_hash, role) VALUES(%s, %s, %s, %s)",
                            (name, email, hashed, role)
                        )
                        print(">>> Query executed", file=sys.stderr)
                        db.commit()
                        
                        st.success("Registration successful! Please login")
                        print(">>> Success message displayed", file=sys.stderr)
                        
                    else:
                        print(">>> ERROR: Database connection is None", file=sys.stderr)
                        st.error("Database connection failed")
                        return
                        
                # except mysql.connector.IntegrityError as ie:
                except pymysql.IntegrityError as ie:
                    print(f">>> IntegrityError: {ie}", file=sys.stderr)
                    st.error("User already exists")
                    return
                except Exception as e:
                    print(f">>> EXCEPTION during database operation: {e}", file=sys.stderr)
                    import traceback
                    traceback.print_exc(file=sys.stderr)
                    st.error(f"Registration failed: {str(e)}")
                    return
                finally:
                    print(">>> Entering finally block...", file=sys.stderr)
                    if cur:
                        try:
                            print(">>> Closing cursor...", file=sys.stderr)
                            cur.close()
                            print(">>> Cursor closed", file=sys.stderr)
                        except Exception as e:
                            print(f">>> Error closing cursor: {e}", file=sys.stderr)
                    if db:
                        try:
                            print(">>> Closing database connection...", file=sys.stderr)
                            db.close()
                            print(">>> Database closed", file=sys.stderr)
                        except Exception as e:
                            print(f">>> Error closing database: {e}", file=sys.stderr)
                
                # Navigate to login
                print(">>> Setting page to login...", file=sys.stderr)
                st.session_state.page = "login"
                print(">>> Page set to login", file=sys.stderr)
                
                print(">>> Calling st.rerun()...", file=sys.stderr)
                st.rerun()
                print(">>> AFTER st.rerun() - THIS SHOULD NOT PRINT", file=sys.stderr)
        
        with col_b:
            if st.button("Back to Login", use_container_width=True):
                print(">>> Back to Login clicked", file=sys.stderr)
                st.session_state.page = "login"
                st.rerun()