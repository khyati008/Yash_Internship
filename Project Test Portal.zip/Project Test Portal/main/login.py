import streamlit as st
import bcrypt
import pymysql.cursors  
from database.db_connection import get_db, close_db

def login():
    st.title("User Login")

    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        
        email = st.text_input("Email", placeholder="your.email@example.com")
        password = st.text_input("Password", type="password", placeholder="Enter password")

        col_a, col_b = st.columns(2)
        
        with col_a:
            if st.button("Login", use_container_width=True):
                if email and password:
                    db = get_db()
                    cur = None  # ← Initialize cursor
                    
                    if db:
                        try:
                            # PyMySQL uses DictCursor instead of dictionary=True
                            cur = db.cursor(pymysql.cursors.DictCursor)  # ← Fixed
                            cur.execute("SELECT * FROM users WHERE email= %s", (email,))
                            user = cur.fetchone()
                            
                            if user and bcrypt.checkpw(password.encode(), user["password_hash"].encode()):
                               st.session_state.user = user
                               st.session_state.page = user["role"]
                               st.success("Login successful!")
                               st.rerun()
                            else:
                               st.error("Invalid Email or Password")
                        except Exception as e:
                            st.error(f"Login error: {e}")
                        finally:
                            close_db(db, cur)
                    else:
                        st.error("Database connection failed")
                else:
                    st.warning("Please fill all fields")
        
        with col_b:
            if st.button("Register", use_container_width=True):
                st.session_state.page = "register"
                st.rerun()
                