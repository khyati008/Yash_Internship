import streamlit as st

def init_session():
    """Initialize all session state variables"""
    if "user" not in st.session_state:
        st.session_state.user = None
    if "page" not in st.session_state:
        st.session_state.page = "home"
    if "test" not in st.session_state:
        st.session_state.test = None
    if "start_time" not in st.session_state:
        st.session_state.start_time = None
    if "answers" not in st.session_state:
        st.session_state.answers = {}
    if "questions" not in st.session_state:
        st.session_state.questions = []

def login_user(user):
    """Login user and redirect based on role"""
    st.session_state.user = user
    st.session_state.page = user["role"]  # Redirects to 'admin' or 'student'

def logout_user():
    """Logout user and clear all session data"""
    st.session_state.user = None
    st.session_state.page = "home"
    st.session_state.test = None
    st.session_state.start_time = None
    st.session_state.answers = {}
    st.session_state.questions = []
    st.success("Logged out successfully!")
    st.rerun()

def is_authenticated():
    """Check if user is logged in"""
    return st.session_state.user is not None

def is_admin():
    """Check if current user is admin"""
    return (st.session_state.user is not None and 
            st.session_state.user.get("role") == "admin")

def is_student():
    """Check if current user is student"""
    return (st.session_state.user is not None and 
            st.session_state.user.get("role") == "student")

def get_current_user():
    """Get current logged-in user"""
    return st.session_state.user

def clear_test_session():
    """Clear test-related session data"""
    st.session_state.test = None
    st.session_state.start_time = None
    st.session_state.answers = {}
    st.session_state.questions = []

def require_auth(page_name="home"):
    """Redirect to login if not authenticated"""
    if not is_authenticated():
        st.warning("Please login to access this page")
        st.session_state.page = "login"
        st.rerun()

def require_admin():
    """Redirect if not admin"""
    if not is_admin():
        st.error("Access denied. Admin only.")
        st.session_state.page = "home"
        st.rerun()

def require_student():
    """Redirect if not student"""
    if not is_student():
        st.error("Access denied. Students only.")
        st.session_state.page = "home"
        st.rerun()