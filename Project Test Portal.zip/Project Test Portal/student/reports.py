import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import pymysql.cursors  # ← Add this
from database.db_connection import get_db, close_db

def student_reports():
    """Student's personalized test results from database"""
    st.title("My Test Results")
    
    db = get_db()
    cursor = None  # ← Initialize
    
    if not db:
        st.error("Database connection failed")
        return
    
    try:
        cursor = db.cursor(pymysql.cursors.DictCursor)  # ← Fixed
        user_id = st.session_state.user['user_id']
        
        # Fetch student's attempts
        query = """
            SELECT 
                t.title,
                a.score,
                t.total_marks,
                a.status,
                DATE_FORMAT(a.end_time, '%Y-%m-%d') as end_time,
                ROUND((a.score / t.total_marks * 100), 2) as percentage
            FROM attempts a
            JOIN tests t ON a.test_id = t.test_id
            WHERE a.user_id = %s AND a.status IN ('completed', 'timeout')
            ORDER BY a.end_time DESC
        """
        cursor.execute(query, (user_id,))
        data = cursor.fetchall()
        
    except Exception as e:
        st.error(f"Error fetching reports: {e}")
        data = []
    finally:
        close_db(db, cursor)

    if not data:
        st.info("No tests attempted yet")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Take a Test", use_container_width=True):
                st.session_state.page = "available_tests"
        with col2:
            if st.button("Back to Dashboard", use_container_width=True):
                st.session_state.page = "student"
        return
    
    df = pd.DataFrame(data)
    
    # Display statistics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
            <h3>{len(df)}</h3>
            <p>Total Tests</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        avg_score = df['percentage'].mean()
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white;">
            <h3>{avg_score:.1f}%</h3>
            <p>Average Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        passed = len(df[df['percentage'] >= 40])
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); color: white;">
            <h3>{passed}</h3>
            <p>Passed</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        highest = df['percentage'].max()
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: white;">
            <h3>{highest:.1f}%</h3>
            <p>Best Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Display table
    st.subheader("Test History")
    display_df = df[['title', 'score', 'total_marks', 'percentage', 'status', 'end_time']].copy()
    display_df.columns = ['Test Name', 'Score', 'Total Marks', 'Percentage (%)', 'Status', 'Date']
    st.dataframe(display_df, use_container_width=True, height=250)
    
    st.markdown("---")
    
    # Performance Charts
    st.subheader("Performance Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Bar chart - Score comparison
        fig1 = px.bar(
            df, 
            x='title', 
            y='percentage',
            title='Score Percentage by Test',
            labels={'title': 'Test Name', 'percentage': 'Percentage (%)'},
            color='percentage',
            color_continuous_scale=['#ef4444', '#f59e0b', '#10b981'],
            text='percentage'
        )
        fig1.update_traces(texttemplate='%{text:.1f}%', textposition='outside')
        fig1.update_layout(showlegend=False, xaxis_tickangle=-45)
        st.plotly_chart(fig1, use_container_width=True)
    
    with col2:
        # Pie chart - Pass/Fail distribution
        pass_count = len(df[df['percentage'] >= 40])
        fail_count = len(df[df['percentage'] < 40])
        
        fig2 = go.Figure(data=[go.Pie(
            labels=['Pass (≥40%)', 'Fail (<40%)'],
            values=[pass_count, fail_count],
            marker_colors=['#10b981', '#ef4444'],
            hole=.4,
            textinfo='label+percent',
            textfont_size=14
        )])
        fig2.update_layout(title='Pass/Fail Distribution')
        st.plotly_chart(fig2, use_container_width=True)
    
    # Line chart - Performance trend
    if len(df) > 1:
        st.subheader("Performance Trend Over Time")
        df_sorted = df.sort_values('end_time')
        df_sorted['test_number'] = range(1, len(df_sorted) + 1)
        
        fig3 = px.line(
            df_sorted,
            x='test_number',
            y='percentage',
            title='Score Trend',
            labels={'test_number': 'Test Number', 'percentage': 'Percentage (%)'},
            markers=True
        )
        fig3.update_traces(
            line_color='#667eea', 
            line_width=3,
            marker=dict(size=12, color='#764ba2')
        )
        fig3.add_hline(
            y=df['percentage'].mean(), 
            line_dash="dash", 
            line_color="red",
            annotation_text=f"Average: {df['percentage'].mean():.1f}%"
        )
        st.plotly_chart(fig3, use_container_width=True)
    
    # Back button
    st.markdown("---")
    if st.button("🔙 Back to Dashboard", use_container_width=True):
        st.session_state.page = "student"