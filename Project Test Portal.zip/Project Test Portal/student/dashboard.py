import streamlit as st
import pymysql.cursors  # ← Add this
from database.db_connection import get_db, close_db
import sys

def student_dashboard():
    print("\n >>>STUDENT_DASHBOARD FUNCTION CALLED", file=sys.stderr)
    """Student dashboard with database statistics"""
    st.title("Student Dashboard")
    st.markdown(f"### Welcome back, {st.session_state.user['name']}!")

    # Fetch student statistics
    print(">>> Getting database connection...", file=sys.stderr)
    db = get_db()
    print(f">>> Database connection object: {db}", file=sys.stderr)

    cur = None  # ← Initialize
    
    if db:
        try:
            cur = db.cursor(pymysql.cursors.DictCursor)  # ← Fixed
            user_id = st.session_state.user['user_id']
            
            # Get completed tests
            print("\n >>>FETCHING USER DATA", file=sys.stderr)
            cur.execute("""
                SELECT COUNT(*) as count 
                FROM attempts 
                WHERE user_id = %s AND status = 'completed'
            """, (user_id,))
            completed_tests = cur.fetchone()['count']
            
            # Get average score
            cur.execute("""
                SELECT AVG((score / total_marks) * 100) as avg_score
                FROM attempts a
                JOIN tests t ON a.test_id = t.test_id
                WHERE a.user_id = %s AND a.status = 'completed'
            """, (user_id,))
            result = cur.fetchone()
            avg_score = result['avg_score'] if result['avg_score'] else 0
            
            # Get available tests
            cur.execute("SELECT COUNT(*) as count FROM tests WHERE is_active = 1")
            available_tests = cur.fetchone()['count']
            
        except Exception as e:
            st.error(f"Error fetching statistics: {e}")
            completed_tests = avg_score = available_tests = 0
        finally:
            close_db(db, cur)
    else:
        completed_tests = avg_score = available_tests = 0

    # Quick stats
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #92806c 0%, #92806c 50%);">
            <h3>{completed_tests}</h3>
            <p>Tests Completed</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #92806c 0%, #92806c 50%);">
            <h3>{avg_score:.1f}%</h3>
            <p>Average Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #92806c 0%, #92806c 100%);">
            <h3>{available_tests}</h3>
            <p>Available Tests</p>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### Quick Actions")

    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        <div class="card">
            <h3>Take Test</h3>
            <p>Attempt available tests and improve your skills</p>
            <ul>
                <li>Multiple choice questions</li>
                <li>Timed assessments</li>
                <li>Instant results</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
        if st.button("View Available Tests", use_container_width=True):
            st.session_state.page = "available_tests"
            st.rerun()
    
    with col2:
        st.markdown("""
        <div class="card">
            <h3>My Reports</h3>
            <p>View your test results and performance analytics</p>
            <ul>
                <li>Detailed score breakdowns</li>
                <li>Performance trends</li>
                <li>Improvement insights</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
        if st.button("View My Reports", use_container_width=True):
            st.session_state.page = "student_reports"
            st.rerun()
    
   