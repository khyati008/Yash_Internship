import streamlit as st
import time
import pymysql.cursors  # ← Add this
from database.db_connection import get_db, close_db

def available_tests():
    """Display available tests from database"""
    st.title("Available Tests")

    db = get_db()
    cursor = None  # ← Initialize
    
    if not db:
        st.error("Database connection failed")
        return
    
    try:
        cursor = db.cursor(pymysql.cursors.DictCursor)  # ← Fixed
        
         # Fetch active tests
        cursor.execute("""
            SELECT test_id, title, duration, total_marks, created_at
            FROM tests 
            WHERE is_active = 1
            ORDER BY created_at DESC
        """)
        tests = cursor.fetchall()
        
        # Get question count for each test
        for test in tests:
            cursor.execute("""
                SELECT COUNT(*) as count 
                FROM questions 
                WHERE test_id = %s
            """, (test['test_id'],))
            test['question_count'] = cursor.fetchone()['count']
        
    except Exception as e:
        st.error(f"Error fetching tests: {e}")
        tests = []
    finally:
        close_db(db, cursor)

    if not tests:
        st.info("No tests available at the moment")
        if st.button("Back to Dashboard"):
            st.session_state.page = "student"
        return
    
    st.markdown("### Choose a test to begin")
    
    for test in tests:
        st.markdown(f"""
        <div class="card">
            <h3>{test['title']}</h3>
            <p><strong>Duration:</strong> {test['duration']} minutes | 
               <strong>Total Marks:</strong> {test['total_marks']} | 
               <strong>Questions:</strong> {test['question_count']}</p>
        </div>
        """, unsafe_allow_html=True)
        
        if st.button(f"Start: {test['title']}", key=f"test_{test['test_id']}", use_container_width=True):
            st.session_state.test = test
            st.session_state.start_time = time.time()
            st.session_state.answers = {}
            st.session_state.page = "attempt_test"
    
    st.markdown("---")
    if st.button("Back to Dashboard", use_container_width=True):
        st.session_state.page = "student"

def attempt_test():
    """Test attempt interface with timer and database"""
    if not st.session_state.test:
        st.error("No test selected")
        if st.button("Go Back"):
            st.session_state.page = "available_tests"
            st.rerun()
        return
    
    test = st.session_state.test
    
    # Timer calculation
    elapsed = int(time.time() - st.session_state.start_time)
    remaining = (test['duration'] * 60) - elapsed
    
    minutes = max(0, remaining // 60)
    seconds = max(0, remaining % 60)
    
    # Timer display with color coding
    timer_class = "timer"
    if remaining > 300:
        timer_color = "#10b981"
    elif remaining > 60:
        timer_color = "#f59e0b"
        timer_class = "timer warning"
    else:
        timer_color = "#ef4444"
        timer_class = "timer danger"
    
    st.markdown(f"""
    <div class="{timer_class}" style="background-color: {timer_color};">
        Time Remaining: {minutes:02d}:{seconds:02d}
    </div>
    """, unsafe_allow_html=True)
    
    # Auto-submit if time's up
    if remaining <= 0:
        st.warning("Time's up! Auto-submitting test...")
        time.sleep(2)
        submit_test(auto_submit=True)
        return
    
    st.markdown(f"<h2>{test['title']}</h2>", unsafe_allow_html=True)
    
    # Fetch questions from database
    db = get_db()
    cursor = None  # ← Initialize
    
    if not db:
        st.error("Database connection failed")
        return
    
    try:
        cursor = db.cursor(pymysql.cursors.DictCursor)  # ← Fixed
        cursor.execute("""
            SELECT * FROM questions 
            WHERE test_id = %s 
            ORDER BY question_id
        """, (test['test_id'],))
        questions = cursor.fetchall()
    except Exception as e:
        st.error(f"Error fetching questions: {e}")
        questions = []
    finally:
        close_db(db, cursor)

    if not questions:
        st.warning("No questions available for this test")
        if st.button("Back to Tests"):
            st.session_state.page = "available_tests"
            st.rerun()
        return

    # Display questions
    for idx, q in enumerate(questions, 1):
        st.markdown(f"""
        <div class="question-card">
            <h4>Question {idx}</h4>
            <p><strong>{q['question_text']}</strong></p>
            <p style="color: #667eea; font-size: 14px;">Marks: {q['marks']}</p>
        </div>
        """, unsafe_allow_html=True)
        
        options = {
            'A': q['option_a'],
            'B': q['option_b'],
            'C': q['option_c'],
            'D': q['option_d']
        }
        
        answer = st.radio(
            "Select your answer:",
            options=['A', 'B', 'C', 'D'],
            format_func=lambda x: f"{x}. {options[x]}",
            key=f"q_{q['question_id']}"
        )
        
        st.session_state.answers[q["question_id"]] = answer
        st.markdown("---")
    
    # Submit button
    col1, col2, col3 = st.columns([1, 1, 1])
    with col2:
        if st.button("Submit Test", use_container_width=True, type="primary"):
            submit_test(auto_submit=False)

def submit_test(auto_submit=False):
    """Submit test and save results to database"""
    test = st.session_state.test
    user = st.session_state.user
    
    db = get_db()
    cursor = None  # ← Initialize
    
    if not db:
        st.error("Database connection failed")
        return
    
    try:
        cursor = db.cursor(pymysql.cursors.DictCursor)  # ← Fixed
        
        # Fetch questions with correct answers
        cursor.execute("""
            SELECT question_id, correct_option, marks 
            FROM questions 
            WHERE test_id = %s
        """, (test['test_id'],))
        questions = cursor.fetchall()
        
        score = 0
        correct_count = 0
        
        # Calculate score
        for q in questions:
            selected = st.session_state.answers.get(q["question_id"])
            is_correct = (selected == q["correct_option"])
            
            if is_correct:
                score += q["marks"]
                correct_count += 1
        
        # Calculate percentage
        total_marks = sum(q["marks"] for q in questions)
        percentage = (score / total_marks) * 100 if total_marks > 0 else 0
        status = "completed" if not auto_submit else "timeout"
        
        # Insert attempt
        insert_attempt = """
            INSERT INTO attempts 
            (user_id, test_id, score, start_time, end_time, status) 
            VALUES (%s, %s, %s, NOW(), NOW(), %s)
        """
        cursor.execute(insert_attempt, (user["user_id"], test["test_id"], score, status))
        attempt_id = cursor.lastrowid
        
        # Insert individual answers
        insert_answer = """
            INSERT INTO answers 
            (attempt_id, question_id, selected_ans, is_correct) 
            VALUES (%s, %s, %s, %s)
        """
        for q in questions:
            selected = st.session_state.answers.get(q["question_id"], "A")
            is_correct = (selected == q["correct_option"])
            cursor.execute(insert_answer, (attempt_id, q["question_id"], selected, is_correct))
        
        db.commit()
        
        # Display results
        pass_status = "Pass" if percentage >= 40 else "Fail"
        
        if pass_status == "Pass":
           # st.balloons()
        
            if auto_submit:
                st.warning("Test auto-submitted due to time expiry")
            else:
                st.success("Test Submitted Successfully!")
        
        st.markdown(f"""
        <div class="results-card">
            <h2>Your Results</h2>
            <h1 class="{'pass' if pass_status == 'Pass' else 'fail'}">{score}/{total_marks}</h1>
            <h3>{percentage:.1f}%</h3>
            <h2 class="{'pass' if pass_status == 'Pass' else 'fail'}">
                {'PASSED' if pass_status == 'Pass' else '❌ FAILED'}
            </h2>
            <p style="font-size: 18px; margin-top: 20px;">
                Correct Answers: {correct_count}/{len(questions)}
            </p>
        </div>
        """, unsafe_allow_html=True)
        
    except Exception as e:
        st.error(f"Error submitting test: {e}")
        db.rollback()
    finally:
        close_db(db, cursor)
    
    # Clear test session
    st.session_state.test = None
    st.session_state.start_time = None
    st.session_state.answers = {}
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("View Detailed Report", use_container_width=True):
            st.session_state.page = "student_reports"
    
    with col2:
        if st.button("Back to Dashboard", use_container_width=True):
            st.session_state.page = "student"