import streamlit as st
import pymysql.cursors  # ← Add this
from database.db_connection import get_db, close_db

def admin_dashboard():
    """Admin dashboard with real database statistics"""
    st.title("Admin Dashboard")
    st.markdown("### Manage tests and view reports")

    # Fetch statistics from database
    db = get_db()
    cursor = None  # ← Initialize
    
    if db:
        try:
            cursor = db.cursor(pymysql.cursors.DictCursor)  # ← Fixed
            
            # Get total tests
            cursor.execute("SELECT COUNT(*) as count FROM tests")
            total_tests = cursor.fetchone()['count']
            
            # Get total questions
            cursor.execute("SELECT COUNT(*) as count FROM questions")
            total_questions = cursor.fetchone()['count']
            
            # Get total students
            cursor.execute("SELECT COUNT(*) as count FROM users WHERE role='student'")
            total_students = cursor.fetchone()['count']
            
            # Get total attempts
            cursor.execute("SELECT COUNT(*) as count FROM attempts")
            total_attempts = cursor.fetchone()['count']
            
        except Exception as e:
            st.error(f"Error fetching statistics: {e}")
            total_tests = total_questions = total_students = total_attempts = 0
        finally:
            close_db(db, cursor)
    else:
        total_tests = total_questions = total_students = total_attempts = 0

    # Statistics row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #667eea 0%, #92806c 100%);">
            <h3>{total_tests}</h3>
            <p>Total Tests</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #92806c 0%, #92806c 100%);">
            <h3>{total_questions}</h3>
            <p>Total Questions</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #92806c 0%, #92806c 100%);">
            <h3>{total_students}</h3>
            <p>Total Students</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #92806c 0%, #92806c 100%);">
            <h3>{total_attempts}</h3>
            <p>Total Attempts</p>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### Quick Actions")

    # Action cards
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="card">
            <h3>Create Test</h3>
            <p>Create new tests for students to attempt</p>
        </div>
        """, unsafe_allow_html=True)
        if st.button("Create Test", use_container_width=True, key="btn_create"):
            st.session_state.page = "create_test"
            st.rerun()

    with col2:
        st.markdown("""
        <div class="card">
            <h3>Add Questions</h3>
            <p>Add questions to existing tests</p>
        </div>
        """, unsafe_allow_html=True)
        if st.button("Add Questions", use_container_width=True, key="btn_questions"):
            st.session_state.page = "add_questions"
            st.rerun()


    with col3:
        st.markdown("""
        <div class="card">
            <h3>Manage Tests</h3>
            <p>View, edit or delete tests and questions</p>
        </div>
        """, unsafe_allow_html=True)
        if st.button("Manage Tests", use_container_width=True, key="btn_manage"):
            st.session_state.mt_view = "list"
            st.session_state.page    = "manage_tests"
            st.rerun()

    with col4:
        st.markdown("""
        <div class="card">
            <h3>View Reports</h3>
            <p>View all student test results</p>
        </div>
        """, unsafe_allow_html=True)
        if st.button("View Reports", use_container_width=True, key="btn_reports"):
            st.session_state.page = "admin_reports"
            st.rerun()
