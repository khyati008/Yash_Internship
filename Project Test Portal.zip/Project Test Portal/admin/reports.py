import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import pymysql.cursors  # ← Add this
from database.db_connection import get_db, close_db

def admin_reports():
    """Admin view of all test results from database"""
    st.title("All Test Results")
    
    db = get_db()
    cursor = None  # ← Initialize
    
    if not db:
        st.error("Database connection failed")
        return
    
    try:
        cursor = db.cursor(pymysql.cursors.DictCursor)  # ← Fixed
        
        # Fetch all attempts with user and test details
        query = """
            SELECT 
                u.name as student,
                t.title,
                a.score,
                t.total_marks,
                a.status,
                DATE_FORMAT(a.end_time, '%Y-%m-%d %H:%i') as end_time
            FROM attempts a
            JOIN users u ON a.user_id = u.user_id
            JOIN tests t ON a.test_id = t.test_id
            WHERE a.status = 'completed'
            ORDER BY a.end_time DESC
        """
        cursor.execute(query)
        data = cursor.fetchall()
        
    except Exception as e:
        st.error(f"Error fetching reports: {e}")
        data = []
    finally:
        close_db(db, cursor)

    if not data:
        st.info("No test attempts yet")
        if st.button("Back to Dashboard"):
            st.session_state.page = "admin"
            st.rerun()
        return
    
    df = pd.DataFrame(data)
    df['percentage'] = (df['score'] / df['total_marks'] * 100).round(2)
    
    # Statistics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
            <h3>{len(df)}</h3>
            <p>Total Attempts</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        avg_score = df['percentage'].mean()
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
            <h3>{avg_score:.1f}%</h3>
            <p>Average Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        passed = len(df[df['percentage'] >= 40])
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
            <h3>{passed}</h3>
            <p>Passed</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        failed = len(df[df['percentage'] < 40])
        st.markdown(f"""
        <div class="stat-card" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);">
            <h3>{failed}</h3>
            <p>Failed</p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Data table
    st.subheader("Test Results Table")
    display_df = df[['student', 'title', 'score', 'total_marks', 'percentage', 'status', 'end_time']].copy()
    display_df.columns = ['Student', 'Test', 'Score', 'Total', 'Percentage (%)', 'Status', 'Date']
    st.dataframe(display_df, use_container_width=True, height=300)
    
    st.markdown("---")
    
    # Charts
    col1, col2 = st.columns(2)
    
    with col1:
        # Test-wise performance
        test_avg = df.groupby('title')['percentage'].mean().reset_index()
        fig1 = px.bar(
            test_avg,
            x='title',
            y='percentage',
            title='Average Score by Test',
            labels={'title': 'Test', 'percentage': 'Avg Score (%)'},
            color='percentage',
            color_continuous_scale='Blues'
        )
        st.plotly_chart(fig1, use_container_width=True)
    
    with col2:
        # Pass/Fail distribution
        pass_fail = pd.DataFrame({
            'Status': ['Pass', 'Fail'],
            'Count': [passed, failed]
        })
        fig2 = px.pie(
            pass_fail,
            values='Count',
            names='Status',
            title='Pass/Fail Distribution',
            color='Status',
            color_discrete_map={'Pass': '#10b981', 'Fail': '#ef4444'}
        )
        st.plotly_chart(fig2, use_container_width=True)
    
    # Back button
    if st.button("Back to Dashboard", use_container_width=True):
        st.session_state.page = "admin"