import streamlit as st
from database.db_connection import get_db, close_db

def create_test():
    """Create new test with database"""
    st.title("Create New Test")

    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
       # st.markdown('<div class="card">', unsafe_allow_html=True)
        
        title = st.text_input(
            "Test Name", 
            placeholder="Enter test name",
            key="test_title"
        )
        
        description = st.text_area(
            "Description",
            placeholder="Enter test description (optional)",
            key="test_desc"
        )
        
        col_a, col_b = st.columns(2)
        
        with col_a:
            duration = st.number_input(
                "Duration (minutes)", 
                min_value=1, 
                value=60,
                key="test_duration"
            )
        
        with col_b:
            total_marks = st.number_input(
                "Total Marks", 
                min_value=1, 
                value=100,
                key="test_marks"
            )
        
        is_active = st.checkbox(
            "Make test active immediately",
            value=True,
            key="test_active"
        )

        st.markdown("---")

        col_x, col_y, col_z = st.columns(3)
        
        with col_x:
            if st.button("Create Test", use_container_width=True):
                if not title:
                    st.warning("Please enter test name")
                else:
                    db = get_db()
                    cursor = None  # ← Initialize
                    
                    if db:
                        try:
                            cursor = db.cursor()  # ← Regular cursor for INSERT
                            
                            # Insert test
                            query = """
                                INSERT INTO tests 
                                (title, duration, total_marks, created_by, is_active) 
                                VALUES (%s, %s, %s, %s, %s)
                            """
                            cursor.execute(
                                query, 
                                (title, duration, total_marks, 
                                 st.session_state.user["user_id"], 1 if is_active else 0)
                            )
                            db.commit()
                            
                            st.success(f"Test '{title}' created successfully!")
                            
                            
                            st.info(f"""
                            **Test Details:**
                            - Name: {title}
                            - Duration: {duration} minutes
                            - Total Marks: {total_marks}
                            - Status: {'Active' if is_active else 'Inactive'}
                            - Test ID: {cursor.lastrowid}
                            """)
                            
                        except Exception as e:
                            st.error(f"Error creating test: {e}")
                        finally:
                            close_db(db, cursor)
                    else:
                        st.error("Database connection failed")
        
        with col_y:
             if st.button("Add Questions", use_container_width=True, key="btn_questions"):
                st.session_state.page = "add_questions"
            
        with col_z:
            if st.button("Back to Dashboard", use_container_width=True):
                st.session_state.page = "admin"
           
           


        st.markdown('</div>', unsafe_allow_html=True)