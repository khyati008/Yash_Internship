import streamlit as st
import pymysql.cursors
from database.db_connection import get_db, close_db

def add_questions():
    """Add questions to existing tests with database"""
    st.title("Add Questions")

    # ── Reset counter — incrementing this clears all form fields ──────────────
    if "form_reset_counter" not in st.session_state:
        st.session_state.form_reset_counter = 0

    r = st.session_state.form_reset_counter  # shorthand

    # ── Fetch active tests ────────────────────────────────────────────────────
    db     = get_db()
    cursor = None

    if not db:
        st.error("Database connection failed")
        return

    try:
        cursor = db.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT test_id, title FROM tests WHERE is_active = 1")
        tests = cursor.fetchall()

    except Exception as e:
        st.error(f"Error fetching tests: {e}")
        tests = []
    finally:
        close_db(db, cursor)

    if not tests:
        st.warning("No tests available. Please create a test first.")
        if st.button("Create Test", use_container_width=True):
            st.session_state.page = "create_test"
            st.rerun()
        return

    # ── Form ──────────────────────────────────────────────────────────────────
    col1, col2, col3 = st.columns([1, 2, 1])

    with col2:
      #  st.markdown('<div class="card">', unsafe_allow_html=True)

        test = st.selectbox(
            "Select Test",
            tests,
            format_func=lambda x: x["title"],
            key="select_test"
        )

        st.markdown("---")

        question = st.text_area(
            "Question",
            placeholder="Enter your question here...",
            height=100,
            key=f"question_text_{r}"       # ← counter in key
        )

        st.markdown("**Options:**")

        option_a = st.text_input(
            "Option A",
            placeholder="Enter option A",
            key=f"opt_a_{r}"               # ← counter in key
        )

        option_b = st.text_input(
            "Option B",
            placeholder="Enter option B",
            key=f"opt_b_{r}"               # ← counter in key
        )

        option_c = st.text_input(
            "Option C",
            placeholder="Enter option C",
            key=f"opt_c_{r}"               # ← counter in key
        )

        option_d = st.text_input(
            "Option D",
            placeholder="Enter option D",
            key=f"opt_d_{r}"               # ← counter in key
        )

        col_x, col_y = st.columns(2)

        with col_x:
            correct = st.selectbox(
                "Correct Option",
                ["A", "B", "C", "D"],
                key=f"correct_opt_{r}"     # ← counter in key
            )

        with col_y:
            marks = st.number_input(
                "Marks",
                min_value=1,
                value=1,
                key=f"question_marks_{r}"  # ← counter in key
            )

        st.markdown("---")

        col_btn1, col_btn2 = st.columns(2)

        with col_btn1:
            if st.button("Add Question", use_container_width=True):
                if not all([question, option_a, option_b, option_c, option_d]):
                    st.warning("Please fill all fields")
                else:
                    db     = get_db()
                    cursor = None

                    if db:
                        try:
                            cursor = db.cursor()
                            cursor.execute("""
                                INSERT INTO questions 
                                (test_id, question_text, option_a, option_b, 
                                 option_c, option_d, correct_option, marks) 
                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                            """, (
                                test["test_id"], question,
                                option_a, option_b, option_c, option_d,
                                correct, marks
                            ))
                            db.commit()
                            st.success(f"✅ Question added to '{test['title']}'!")

                            # ✅ Increment counter — resets all form fields
                            st.session_state.form_reset_counter += 1
                            st.rerun()

                        except Exception as e:
                            st.error(f"Error adding question: {e}")
                        finally:
                            close_db(db, cursor)
                    else:
                        st.error("Database connection failed")

        with col_btn2:
            if st.button("Back to Dashboard", use_container_width=True):
                st.session_state.page = "admin"
                st.rerun()

        st.markdown('</div>', unsafe_allow_html=True)