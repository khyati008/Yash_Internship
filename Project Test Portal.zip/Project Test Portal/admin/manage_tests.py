import streamlit as st
import pymysql.cursors
from database.db_connection import get_db, close_db


# ── DB helpers ────────────────────────────────────────────────────────────────

def _fetch_all_tests():
    db, cur = get_db(), None
    tests = []
    if not db:
        return tests
    try:
        cur = db.cursor(pymysql.cursors.DictCursor)
        cur.execute("""
            SELECT t.test_id, t.title, t.duration, t.total_marks,
                   t.is_active, t.created_at,
                   (SELECT COUNT(*) FROM questions q WHERE q.test_id = t.test_id) AS question_count
            FROM tests t
            ORDER BY t.created_at DESC
        """)
        tests = cur.fetchall()
    except Exception as e:
        st.error(f"Error fetching tests: {e}")
    finally:
        close_db(db, cur)
    return tests


def _fetch_questions(test_id):
    db, cur = get_db(), None
    questions = []
    if not db:
        return questions
    try:
        cur = db.cursor(pymysql.cursors.DictCursor)
        cur.execute("""
            SELECT question_id, question_text, option_a, option_b,
                   option_c, option_d, correct_option, marks
            FROM questions
            WHERE test_id = %s
            ORDER BY question_id
        """, (test_id,))
        questions = cur.fetchall()
    except Exception as e:
        st.error(f"Error fetching questions: {e}")
    finally:
        close_db(db, cur)
    return questions


def _update_test(test_id, title, duration, total_marks, is_active):
    db, cur = get_db(), None
    try:
        cur = db.cursor()
        cur.execute("""
            UPDATE tests
            SET title=%s, duration=%s, total_marks=%s, is_active=%s
            WHERE test_id=%s
        """, (title, duration, total_marks, is_active, test_id))
        db.commit()
        return True, "Test updated successfully."
    except Exception as e:
        if db: db.rollback()
        return False, str(e)
    finally:
        close_db(db, cur)


def _delete_test(test_id):
    db, cur = get_db(), None
    try:
        cur = db.cursor()
        cur.execute("DELETE FROM questions WHERE test_id = %s", (test_id,))
        cur.execute("DELETE FROM attempts  WHERE test_id = %s", (test_id,))
        cur.execute("DELETE FROM tests     WHERE test_id = %s", (test_id,))
        db.commit()
        return True, "Test deleted."
    except Exception as e:
        if db: db.rollback()
        return False, str(e)
    finally:
        close_db(db, cur)


def _update_question(question_id, question_text, opt_a, opt_b, opt_c, opt_d, correct, marks):
    db, cur = get_db(), None
    try:
        cur = db.cursor()
        cur.execute("""
            UPDATE questions
            SET question_text=%s, option_a=%s, option_b=%s,
                option_c=%s, option_d=%s, correct_option=%s, marks=%s
            WHERE question_id=%s
        """, (question_text, opt_a, opt_b, opt_c, opt_d, correct, marks, question_id))
        db.commit()
        return True, "Question updated."
    except Exception as e:
        if db: db.rollback()
        return False, str(e)
    finally:
        close_db(db, cur)


def _delete_question(question_id):
    db, cur = get_db(), None
    try:
        cur = db.cursor()
        cur.execute("DELETE FROM questions WHERE question_id = %s", (question_id,))
        db.commit()
        return True, "Question deleted."
    except Exception as e:
        if db: db.rollback()
        return False, str(e)
    finally:
        close_db(db, cur)


# ── Sub-pages ─────────────────────────────────────────────────────────────────

def _test_list_page():
    st.title(" Manage Tests")
    st.markdown("View, edit or delete existing tests and their questions.")

    if st.button("← Back to Dashboard", key="mt_back"):
        st.session_state.page = "admin"
        st.rerun()

    st.markdown("---")

    tests = _fetch_all_tests()

    if not tests:
        st.info("No tests found. Create one first.")
        return

    search = st.text_input(" Search tests", placeholder="Type a title keyword...")
    if search:
        tests = [t for t in tests if search.lower() in t['title'].lower()]

    if not tests:
        st.info("No tests match your search.")
        return

    st.markdown(f"**{len(tests)} test(s) found**")
    st.markdown("---")

    # Init delete confirmation flags
    for t in tests:
        if f"del_test_{t['test_id']}" not in st.session_state:
            st.session_state[f"del_test_{t['test_id']}"] = False

    for test in tests:
        status_label = "🟢 Active" if test["is_active"] else "🔴 Inactive"

        st.markdown(f"""
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <h3 style="margin:0;">{test['title']}</h3>
                <span style="font-size:13px; color:#666;">{status_label}</span>
            </div>
            <p style="margin: 6px 0 0 0; font-size:13px;">
                {test['duration']} min &nbsp;|&nbsp;
                {test['total_marks']} marks &nbsp;|&nbsp;
                {test['question_count']} questions
            </p>
        </div>
        """, unsafe_allow_html=True)

        c1, c2, c3, _ = st.columns([1, 1, 1, 3])

        with c1:
            if st.button(" View", key=f"view_{test['test_id']}", use_container_width=True):
                st.session_state.mt_selected_test = test
                st.session_state.mt_view          = "questions"
                st.rerun()

        with c2:
            if st.button(" Edit", key=f"edit_{test['test_id']}", use_container_width=True):
                st.session_state.mt_selected_test = test
                st.session_state.mt_view          = "edit_test"
                st.rerun()

        with c3:
            del_key = f"del_test_{test['test_id']}"
            if not st.session_state[del_key]:
                if st.button(" Delete", key=f"del_{test['test_id']}", use_container_width=True):
                    st.session_state[del_key] = True
                    st.rerun()
            else:
                st.warning(f"Delete **{test['title']}**? Removes all questions & attempts.")
                y, n = st.columns(2)
                with y:
                    if st.button(" Yes", key=f"yes_del_{test['test_id']}", use_container_width=True):
                        ok, msg = _delete_test(test["test_id"])
                        st.session_state[del_key] = False
                        st.success(msg) if ok else st.error(f"Failed: {msg}")
                        st.rerun()
                with n:
                    if st.button(" No", key=f"no_del_{test['test_id']}", use_container_width=True):
                        st.session_state[del_key] = False
                        st.rerun()

        st.markdown("<hr style='margin: 6px 0;'>", unsafe_allow_html=True)


def _edit_test_page():
    test = st.session_state.get("mt_selected_test")
    if not test:
        st.session_state.mt_view = "list"
        st.rerun()

    st.title(" Edit Test")

    if st.button(" Back to Tests", key="edit_back"):
        st.session_state.mt_view = "list"
        st.rerun()

    st.markdown("---")

    with st.form("edit_test_form"):
        title = st.text_input("Test Title *", value=test['title'])

        c1, c2 = st.columns(2)
        with c1:
            duration = st.number_input("Duration (minutes)", min_value=1, value=int(test['duration']))
        with c2:
            total_marks = st.number_input("Total Marks", min_value=1, value=int(test['total_marks']))

        is_active = st.checkbox("Active", value=bool(test['is_active']))

        saved = st.form_submit_button(" Save Changes", use_container_width=True)

    if saved:
        if not title.strip():
            st.warning("Title cannot be empty.")
        else:
            ok, msg = _update_test(
                test['test_id'], title.strip(),
                duration, total_marks, is_active
            )
            if ok:
                st.success(f" {msg}")
                st.session_state.mt_selected_test['title']       = title.strip()
                st.session_state.mt_selected_test['duration']    = duration
                st.session_state.mt_selected_test['total_marks'] = total_marks
                st.session_state.mt_selected_test['is_active']   = is_active
            else:
                st.error(f"Failed: {msg}")


def _questions_page():
    test = st.session_state.get("mt_selected_test")
    if not test:
        st.session_state.mt_view = "list"
        st.rerun()

    st.title(f" Questions — {test['title']}")
    st.markdown(
        f" {test['duration']} min &nbsp;|&nbsp; "
        f" {test['total_marks']} marks &nbsp;|&nbsp; "
        f"{'🟢 Active' if test['is_active'] else '🔴 Inactive'}"
    )

    if st.button(" Back to Tests", key="q_back"):
        st.session_state.mt_view = "list"
        st.rerun()

    st.markdown("---")

    questions = _fetch_questions(test["test_id"])

    # Init state flags per question
    for q in questions:
        if f"edit_q_{q['question_id']}" not in st.session_state:
            st.session_state[f"edit_q_{q['question_id']}"] = False
        if f"del_q_{q['question_id']}"  not in st.session_state:
            st.session_state[f"del_q_{q['question_id']}"]  = False

    if not questions:
        st.info("No questions yet. Add one below.")
    else:
        st.markdown(f"### {len(questions)} Question(s)")

        for i, q in enumerate(questions, start=1):
            edit_key = f"edit_q_{q['question_id']}"
            del_key  = f"del_q_{q['question_id']}"
            preview  = q['question_text'][:70] + ("..." if len(q['question_text']) > 70 else "")

            with st.expander(f"Q{i}: {preview}", expanded=False):

                if not st.session_state[edit_key]:
                    # READ mode
                    st.markdown(f"**{q['question_text']}**")
                    c1, c2 = st.columns(2)
                    with c1:
                        st.markdown(f"- **A:** {q['option_a']}")
                        st.markdown(f"- **B:** {q['option_b']}")
                    with c2:
                        st.markdown(f"- **C:** {q['option_c']}")
                        st.markdown(f"- **D:** {q['option_d']}")
                    st.markdown(
                        f" **Correct:** {q['correct_option']} &nbsp;|&nbsp; "
                        f"**Marks:** {q['marks']}"
                    )

                    btn1, btn2 = st.columns(2)
                    with btn1:
                        if st.button(" Edit", key=f"edit_btn_{q['question_id']}", use_container_width=True):
                            st.session_state[edit_key] = True
                            st.rerun()
                    with btn2:
                        if not st.session_state[del_key]:
                            if st.button(" Delete", key=f"del_btn_{q['question_id']}", use_container_width=True):
                                st.session_state[del_key] = True
                                st.rerun()
                        else:
                            st.warning("Are you sure?")
                            y, n = st.columns(2)
                            with y:
                                if st.button(" Yes", key=f"yes_q_{q['question_id']}", use_container_width=True):
                                    ok, msg = _delete_question(q["question_id"])
                                    st.session_state[del_key] = False
                                    st.success(msg) if ok else st.error(f"Failed: {msg}")
                                    st.rerun()
                            with n:
                                if st.button(" No", key=f"no_q_{q['question_id']}", use_container_width=True):
                                    st.session_state[del_key] = False
                                    st.rerun()

                else:
                    # EDIT mode
                    with st.form(key=f"edit_q_form_{q['question_id']}"):
                        new_text = st.text_area("Question *", value=q['question_text'], height=80)
                        ec1, ec2 = st.columns(2)
                        with ec1:
                            new_opt_a = st.text_input("Option A *", value=q['option_a'])
                            new_opt_c = st.text_input("Option C *", value=q['option_c'])
                        with ec2:
                            new_opt_b = st.text_input("Option B *", value=q['option_b'])
                            new_opt_d = st.text_input("Option D *", value=q['option_d'])

                        ec3, ec4 = st.columns(2)
                        with ec3:
                            options     = ["A", "B", "C", "D"]
                            correct_idx = options.index(q['correct_option']) if q['correct_option'] in options else 0
                            new_correct = st.selectbox("Correct Answer *", options, index=correct_idx)
                        with ec4:
                            new_marks = st.number_input("Marks", min_value=1, value=int(q['marks']))

                        sc1, sc2 = st.columns(2)
                        with sc1:
                            save_q = st.form_submit_button(" Save", use_container_width=True)
                        with sc2:
                            cancel_q = st.form_submit_button(" Cancel", use_container_width=True)

                    if save_q:
                        if not all([new_text, new_opt_a, new_opt_b, new_opt_c, new_opt_d]):
                            st.warning("Please fill all fields.")
                        else:
                            ok, msg = _update_question(
                                q['question_id'], new_text,
                                new_opt_a, new_opt_b, new_opt_c, new_opt_d,
                                new_correct, new_marks
                            )
                            if ok:
                                st.success(f" {msg}")
                                st.session_state[edit_key] = False
                                st.rerun()
                            else:
                                st.error(f"Failed: {msg}")

                    if cancel_q:
                        st.session_state[edit_key] = False
                        st.rerun()

    # ── Add new question ──────────────────────────────────────────────────────
    st.markdown("---")
    st.markdown("###  Add New Question")

    if "mt_add_q_reset" not in st.session_state:
        st.session_state.mt_add_q_reset = 0
    r = st.session_state.mt_add_q_reset

    with st.form(key=f"add_q_form_{r}"):
        new_q = st.text_area("Question Text *", placeholder="Enter question...", height=80)

        ac1, ac2 = st.columns(2)
        with ac1:
            a_opt_a = st.text_input("Option A *", placeholder="Option A")
            a_opt_b = st.text_input("Option B *", placeholder="Option B")
        with ac2:
            a_opt_c = st.text_input("Option C *", placeholder="Option C")
            a_opt_d = st.text_input("Option D *", placeholder="Option D")

        ac3, ac4 = st.columns(2)
        with ac3:
            a_correct = st.selectbox("Correct Answer *", ["A", "B", "C", "D"])
        with ac4:
            a_marks = st.number_input("Marks", min_value=1, value=1)

        add_btn = st.form_submit_button(" Add Question", use_container_width=True)

    if add_btn:
        if not all([new_q, a_opt_a, a_opt_b, a_opt_c, a_opt_d]):
            st.warning("Please fill all fields.")
        else:
            db, cur = get_db(), None
            try:
                cur = db.cursor()
                cur.execute("""
                    INSERT INTO questions
                        (test_id, question_text, option_a, option_b, option_c, option_d, correct_option, marks)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """, (test["test_id"], new_q, a_opt_a, a_opt_b, a_opt_c, a_opt_d, a_correct, a_marks))
                db.commit()
                st.success(" Question added!")
                st.session_state.mt_add_q_reset += 1
                st.rerun()
            except Exception as e:
                if db: db.rollback()
                st.error(f"Failed: {e}")
            finally:
                close_db(db, cur)


# ── Entry point ───────────────────────────────────────────────────────────────

def manage_tests():
    if "mt_view" not in st.session_state:
        st.session_state.mt_view = "list"

    view = st.session_state.mt_view

    if view == "list":
        _test_list_page()
    elif view == "edit_test":
        _edit_test_page()
    elif view == "questions":
        _questions_page()
    else:
        st.session_state.mt_view = "list"
        st.rerun()